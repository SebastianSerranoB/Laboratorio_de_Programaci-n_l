/*
 * parser.h
 *
 *  Created on: 31 ago 2022
 *      Author: admin
 */

#ifndef PARSER_H_
#define PARSER_H_

int parser_FromText(FILE* pFile, LinkedList* lista);

#endif /* PARSER_H_ */
