/*
 * controller.c
 *
 *  Created on: 31 ago 2022
 *      Author: admin
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "LinkedList.h"
#include "Pokemon.h"
#include "controller.h"
#include "alumno.h"
#include "parser.h"


int controller_loadFromText(char* path , LinkedList* listaEntidad)
{
	int retorno = -1;

	FILE* pArchivo = NULL;

	if(listaEntidad != NULL && path != NULL)
	{
		pArchivo = fopen(path,"r");

		if(pArchivo != NULL)
		{
			if(parser_FromText(pArchivo, listaEntidad) > -1){
				printf("\nLista cargada con exito!");
				retorno = 0;
			}else{
				printf("\nError, el archivo fue abierto pero no pudo leerse.");
			}

		}
		else
		{
			printf("\nError! no pudo leerse el archivo.");
		}

		fclose(pArchivo);
	}

	return retorno;
}

int controller_List(LinkedList* pListaPokemon)
{
	int retorno;
	retorno = -1;

	if(printList(pListaPokemon) == 0)
	{
		retorno = 0;
		printf("\nListado con exito!");
	}
	else{
		printf("\nDebe haber al menos un elemento en lista para mostrarla.");
	}


	return retorno;
}

int controller_map(LinkedList* pArrayList)
{
	int retorno = -1;
	int opcionMenu;

	if(pArrayList != NULL && ll_len(pArrayList) > 0)
	{
		//mi map function clona la lista enviada como parametro y la retorna mapeado,
		//en este caso la igual a la original por comodidad, sino genero una nueva y retorno linked en el controller
		opcionMenu = printMenu(1,3,"\n===MENU MAP ===\n1-DIA DESPEJADO\n2-EVENTO KANTO\n3 Salir al menu principal. ");
		switch(opcionMenu)
		{
		case 1:
			pArrayList = ll_map(pArrayList,Pokemon_mapearValorDeAtaque);
			printf("\nLista Mapeada con exito(clima despejado)");

			break;
		case 2:
			pArrayList = ll_map(pArrayList, Pokemon_mapearEventoKanto);
			printf("\nLista mapeada con exito(evento kanto)");

			break;
		case 3:
			printf("\nSaliendo al menu principal...");
			break;
		}
		retorno = 0;
	}else
	{
		printf("\nError, asegurese de que existan elementos en lista para mapear.");
	}

	return retorno;
}

int controller_BatallaPokemon(LinkedList* listaPokemon)
{
	int retorno;

	if(listaPokemon != NULL && ll_len(listaPokemon) > 0)
	{
			retorno = ll_count(listaPokemon, criterioBatallaPokemon);
			if(retorno > 2)
			{
				printf("\nVICTORIA! DERROTASTE AL LIDER ROCKET");
			}
			else
			{
				printf("\nDERROTA! LLEVA A TUS POKEMONS A UN CENTRO MEDICO!");
			}
	}
	else
	{
		printf("\nError, no existen elementos en lista");
	}

	return retorno;

}
